
#include "MyLibrary.h"


int main(int agrc, char** argv) {
	MyLibrary lib;
	lib.sayBye();
	return 0;
}
