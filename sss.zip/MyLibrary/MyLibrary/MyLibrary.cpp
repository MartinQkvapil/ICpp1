#include "MyLibrary.h"
#include <iostream>


void MyLibrary::sayHello() const
{
	std::cout << "Hello from lib" << std::endl;
}

void MyLibrary::sayBye() const
{
	std::cout << "Bye from lib" << std::endl;
}
