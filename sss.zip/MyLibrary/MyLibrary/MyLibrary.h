#ifndef MY_LIBRARY_H
#define MY_LIBRARY_H

#ifndef MYLIBRARY_EXPORTS
#define MY_LIBRARY_DYN_LIB __declspec(dllexport)
#else

#define MY_LIBRARY_DYN_LIB __declspec(dllimport)

#endif // !MYLIBRARY_EXPORTS

class MY_LIBRARY_DYN_LIB MyLibrary {
public:
	void sayHello() const;
	void sayBye() const;
};



#endif // !MY_LIBRART_H
